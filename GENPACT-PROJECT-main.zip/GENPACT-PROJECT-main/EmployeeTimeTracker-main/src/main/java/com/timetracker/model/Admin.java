package com.timetracker.model;

public class Admin {

}
